import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, TrendingUp, Shield, Users, Award, ArrowRight } from 'lucide-react';
import AnimatedCounter from '../components/UI/AnimatedCounter';
import PropertyCard from '../components/UI/PropertyCard';
import { kpiData, properties, newsArticles } from '../data/mockData';

const HomePage: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      notation: 'compact'
    }).format(amount);
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.pexels.com/photos/2159065/pexels-photo-2159065.jpeg" 
            alt="Modern cityscape" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-charcoal-900/80 to-charcoal-800/60"></div>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className={`transition-all duration-1000 ${isVisible ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-10'}`}>
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
              Build Wealth Through
              <span className="block text-emerald-400">Smart Real Estate</span>
            </h1>
            <p className="text-xl md:text-2xl text-charcoal-200 mb-8 max-w-3xl mx-auto">
              Join thousands of investors earning consistent returns through our professionally managed 
              commercial real estate portfolio.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link 
                to="/invest" 
                className="bg-primary-600 hover:bg-primary-700 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-all duration-300 flex items-center justify-center group"
              >
                Start Investing
                <ChevronRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link 
                to="/portfolio" 
                className="border-2 border-white text-white hover:bg-white hover:text-charcoal-900 px-8 py-4 rounded-lg text-lg font-semibold transition-all duration-300"
              >
                View Portfolio
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* KPI Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-charcoal-800 mb-4">
              Our Story in Numbers
            </h2>
            <p className="text-xl text-charcoal-600 max-w-3xl mx-auto">
              Proven performance and growing trust from investors worldwide
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center p-6 rounded-xl bg-gradient-to-br from-primary-50 to-primary-100 animate-slide-up">
              <div className="text-4xl md:text-5xl font-bold text-primary-600 mb-2">
                <AnimatedCounter 
                  end={kpiData.totalAssets} 
                  prefix="$" 
                  suffix="B" 
                  decimals={1}
                />
              </div>
              <p className="text-charcoal-600 font-medium">Assets Under Management</p>
            </div>
            
            <div className="text-center p-6 rounded-xl bg-gradient-to-br from-emerald-50 to-emerald-100 animate-slide-up" style={{animationDelay: '0.1s'}}>
              <div className="text-4xl md:text-5xl font-bold text-emerald-600 mb-2">
                <AnimatedCounter 
                  end={kpiData.averageYield} 
                  suffix="%" 
                  decimals={1}
                />
              </div>
              <p className="text-charcoal-600 font-medium">Average Annual Yield</p>
            </div>
            
            <div className="text-center p-6 rounded-xl bg-gradient-to-br from-yellow-50 to-yellow-100 animate-slide-up" style={{animationDelay: '0.2s'}}>
              <div className="text-4xl md:text-5xl font-bold text-yellow-600 mb-2">
                <AnimatedCounter end={kpiData.propertiesOwned} />
              </div>
              <p className="text-charcoal-600 font-medium">Properties Owned</p>
            </div>
            
            <div className="text-center p-6 rounded-xl bg-gradient-to-br from-purple-50 to-purple-100 animate-slide-up" style={{animationDelay: '0.3s'}}>
              <div className="text-4xl md:text-5xl font-bold text-purple-600 mb-2">
                <AnimatedCounter 
                  end={kpiData.investorGrowth} 
                  suffix="%" 
                  decimals={1}
                />
              </div>
              <p className="text-charcoal-600 font-medium">YoY Investor Growth</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Properties */}
      <section className="py-20 bg-charcoal-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-charcoal-800 mb-4">
                Featured Properties
              </h2>
              <p className="text-xl text-charcoal-600">
                Prime commercial real estate generating consistent returns
              </p>
            </div>
            <Link 
              to="/portfolio" 
              className="mt-6 md:mt-0 flex items-center text-primary-600 hover:text-primary-700 font-semibold group"
            >
              View All Properties
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {properties.slice(0, 3).map((property) => (
              <PropertyCard 
                key={property.id} 
                property={property}
                onClick={() => {/* Navigate to property detail */}}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Why Invest Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-charcoal-800 mb-4">
              Why Invest with SAIR Trust
            </h2>
            <p className="text-xl text-charcoal-600 max-w-3xl mx-auto">
              Decades of expertise, transparent operations, and a proven track record of success
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center p-6 group">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-primary-200 transition-colors">
                <TrendingUp className="w-8 h-8 text-primary-600" />
              </div>
              <h3 className="text-xl font-semibold text-charcoal-800 mb-3">Proven Returns</h3>
              <p className="text-charcoal-600">
                Consistent performance with average annual yields of 8.2% over the past decade.
              </p>
            </div>
            
            <div className="text-center p-6 group">
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-emerald-200 transition-colors">
                <Shield className="w-8 h-8 text-emerald-600" />
              </div>
              <h3 className="text-xl font-semibold text-charcoal-800 mb-3">Risk Management</h3>
              <p className="text-charcoal-600">
                Diversified portfolio across property types and geographic regions to minimize risk.
              </p>
            </div>
            
            <div className="text-center p-6 group">
              <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-yellow-200 transition-colors">
                <Users className="w-8 h-8 text-yellow-600" />
              </div>
              <h3 className="text-xl font-semibold text-charcoal-800 mb-3">Expert Management</h3>
              <p className="text-charcoal-600">
                Led by industry veterans with decades of commercial real estate experience.
              </p>
            </div>
            
            <div className="text-center p-6 group">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-purple-200 transition-colors">
                <Award className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold text-charcoal-800 mb-3">Transparency</h3>
              <p className="text-charcoal-600">
                Regular reporting, live dashboard updates, and direct communication with management.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Latest News */}
      <section className="py-20 bg-charcoal-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-charcoal-800 mb-4">
                Latest News & Insights
              </h2>
              <p className="text-xl text-charcoal-600">
                Stay updated with market trends and company developments
              </p>
            </div>
            <Link 
              to="/news" 
              className="mt-6 md:mt-0 flex items-center text-primary-600 hover:text-primary-700 font-semibold group"
            >
              View All News
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {newsArticles.slice(0, 2).map((article) => (
              <div key={article.id} className="bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 overflow-hidden group cursor-pointer">
                <img 
                  src={article.image} 
                  alt={article.title}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-medium text-primary-600 bg-primary-100 px-3 py-1 rounded-full">
                      {article.category}
                    </span>
                    <span className="text-sm text-charcoal-500">
                      {new Date(article.publishedAt).toLocaleDateString()}
                    </span>
                  </div>
                  <h3 className="text-xl font-semibold text-charcoal-800 mb-3 group-hover:text-primary-600 transition-colors">
                    {article.title}
                  </h3>
                  <p className="text-charcoal-600 mb-4">
                    {article.excerpt}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-charcoal-500">By {article.author}</span>
                    <ArrowRight className="w-4 h-4 text-charcoal-400 group-hover:text-primary-600 group-hover:translate-x-1 transition-all" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;