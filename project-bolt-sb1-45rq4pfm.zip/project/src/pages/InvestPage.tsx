import React, { useState } from 'react';
import { Calculator, TrendingUp, Shield, Users, ArrowRight, DollarSign, Clock, BarChart3 } from 'lucide-react';
import { investmentOpportunities } from '../data/mockData';

const InvestPage: React.FC = () => {
  const [calculatorAmount, setCalculatorAmount] = useState(50000);
  const [selectedYield, setSelectedYield] = useState(8.2);

  const monthlyReturn = (calculatorAmount * selectedYield / 100) / 12;
  const annualReturn = calculatorAmount * selectedYield / 100;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-emerald-600 to-emerald-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Start Investing Today
            </h1>
            <p className="text-xl text-emerald-100 max-w-3xl mx-auto mb-8">
              Join thousands of investors building wealth through professionally managed commercial real estate
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-white text-emerald-800 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-emerald-50 transition-colors">
                Open Account
              </button>
              <button className="border-2 border-white text-white hover:bg-white hover:text-emerald-800 px-8 py-4 rounded-lg text-lg font-semibold transition-colors">
                Download Brochure
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* How to Invest Steps */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-charcoal-800 mb-4">
              How to Invest
            </h2>
            <p className="text-xl text-charcoal-600 max-w-3xl mx-auto">
              Getting started is simple. Follow these steps to begin your real estate investment journey.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center group">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-primary-200 transition-colors">
                <span className="text-2xl font-bold text-primary-600">1</span>
              </div>
              <h3 className="text-xl font-semibold text-charcoal-800 mb-4">Create Account</h3>
              <p className="text-charcoal-600 leading-relaxed">
                Complete our simple online application and verify your identity. 
                The process takes just a few minutes and is completely secure.
              </p>
            </div>

            <div className="text-center group">
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-emerald-200 transition-colors">
                <span className="text-2xl font-bold text-emerald-600">2</span>
              </div>
              <h3 className="text-xl font-semibold text-charcoal-800 mb-4">Fund Account</h3>
              <p className="text-charcoal-600 leading-relaxed">
                Transfer funds securely via bank transfer, wire, or check. 
                Minimum investment starts at just $1,000 for most opportunities.
              </p>
            </div>

            <div className="text-center group">
              <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-yellow-200 transition-colors">
                <span className="text-2xl font-bold text-yellow-600">3</span>
              </div>
              <h3 className="text-xl font-semibold text-charcoal-800 mb-4">Start Earning</h3>
              <p className="text-charcoal-600 leading-relaxed">
                Choose from available opportunities and start earning monthly dividends. 
                Track your investments through our investor dashboard.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Investment Calculator */}
      <section className="py-20 bg-charcoal-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-charcoal-800 mb-4">
              Investment Calculator
            </h2>
            <p className="text-xl text-charcoal-600">
              Estimate your potential returns with our interactive calculator
            </p>
          </div>

          <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2">
              {/* Calculator Input */}
              <div className="p-8 lg:p-12">
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-charcoal-700 mb-2">
                      Investment Amount
                    </label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-charcoal-400 w-5 h-5" />
                      <input
                        type="number"
                        value={calculatorAmount}
                        onChange={(e) => setCalculatorAmount(Number(e.target.value))}
                        className="w-full pl-10 pr-4 py-3 border border-charcoal-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent text-lg"
                        min="1000"
                        step="1000"
                      />
                    </div>
                    <input
                      type="range"
                      min="1000"
                      max="1000000"
                      step="1000"
                      value={calculatorAmount}
                      onChange={(e) => setCalculatorAmount(Number(e.target.value))}
                      className="w-full h-2 bg-charcoal-200 rounded-lg mt-4 slider"
                    />
                    <div className="flex justify-between text-sm text-charcoal-500 mt-2">
                      <span>$1,000</span>
                      <span>$1,000,000</span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-charcoal-700 mb-2">
                      Expected Annual Yield
                    </label>
                    <select
                      value={selectedYield}
                      onChange={(e) => setSelectedYield(Number(e.target.value))}
                      className="w-full px-4 py-3 border border-charcoal-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent text-lg"
                    >
                      <option value={7.2}>7.2% - Conservative</option>
                      <option value={8.2}>8.2% - Balanced (Average)</option>
                      <option value={9.5}>9.5% - Growth</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Calculator Results */}
              <div className="bg-primary-600 p-8 lg:p-12 text-white">
                <h3 className="text-2xl font-bold mb-8">Projected Returns</h3>
                
                <div className="space-y-6">
                  <div className="flex items-center justify-between p-4 bg-primary-700 rounded-lg">
                    <div className="flex items-center">
                      <Clock className="w-6 h-6 mr-3" />
                      <span>Monthly Income</span>
                    </div>
                    <span className="text-2xl font-bold">
                      {formatCurrency(monthlyReturn)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-primary-700 rounded-lg">
                    <div className="flex items-center">
                      <BarChart3 className="w-6 h-6 mr-3" />
                      <span>Annual Income</span>
                    </div>
                    <span className="text-2xl font-bold">
                      {formatCurrency(annualReturn)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-primary-700 rounded-lg">
                    <div className="flex items-center">
                      <TrendingUp className="w-6 h-6 mr-3" />
                      <span>5-Year Total</span>
                    </div>
                    <span className="text-2xl font-bold">
                      {formatCurrency(calculatorAmount + (annualReturn * 5))}
                    </span>
                  </div>
                </div>

                <div className="mt-8 p-4 bg-primary-700 rounded-lg">
                  <p className="text-sm opacity-90">
                    * Projections are based on historical performance and current market conditions. 
                    Actual returns may vary. Past performance does not guarantee future results.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Current Opportunities */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-charcoal-800 mb-4">
              Current Investment Opportunities
            </h2>
            <p className="text-xl text-charcoal-600">
              Exclusive access to institutional-quality real estate investments
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {investmentOpportunities.map((opportunity) => (
              <div key={opportunity.id} className="bg-white border border-charcoal-200 rounded-xl p-8 hover:shadow-lg transition-shadow">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-semibold text-charcoal-800 mb-2">
                      {opportunity.title}
                    </h3>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      opportunity.status === 'open' ? 'bg-emerald-100 text-emerald-800' :
                      opportunity.status === 'closed' ? 'bg-charcoal-100 text-charcoal-600' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {opportunity.status === 'open' ? 'Open for Investment' :
                       opportunity.status === 'closed' ? 'Fully Funded' : 'Coming Soon'}
                    </span>
                  </div>
                  <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                    opportunity.riskLevel === 'low' ? 'bg-emerald-100 text-emerald-800' :
                    opportunity.riskLevel === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {opportunity.riskLevel.toUpperCase()} RISK
                  </div>
                </div>

                <p className="text-charcoal-600 mb-6">
                  {opportunity.description}
                </p>

                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div>
                    <div className="text-sm text-charcoal-500">Target Amount</div>
                    <div className="text-lg font-semibold text-charcoal-800">
                      {formatCurrency(opportunity.targetAmount)}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-charcoal-500">Raised</div>
                    <div className="text-lg font-semibold text-charcoal-800">
                      {formatCurrency(opportunity.raisedAmount)}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-charcoal-500">Min Investment</div>
                    <div className="text-lg font-semibold text-charcoal-800">
                      {formatCurrency(opportunity.minimumInvestment)}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-charcoal-500">Projected Yield</div>
                    <div className="text-lg font-semibold text-emerald-600">
                      {opportunity.projectedYield}%
                    </div>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="mb-6">
                  <div className="flex justify-between text-sm text-charcoal-600 mb-2">
                    <span>Funding Progress</span>
                    <span>{Math.round((opportunity.raisedAmount / opportunity.targetAmount) * 100)}%</span>
                  </div>
                  <div className="w-full bg-charcoal-200 rounded-full h-2">
                    <div 
                      className="bg-emerald-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${(opportunity.raisedAmount / opportunity.targetAmount) * 100}%` }}
                    ></div>
                  </div>
                </div>

                <div className="flex justify-between items-center">
                  <div className="text-sm text-charcoal-600">
                    Timeline: {opportunity.timeline}
                  </div>
                  <button 
                    className={`px-6 py-2 rounded-lg font-medium transition-colors ${
                      opportunity.status === 'open' 
                        ? 'bg-primary-600 text-white hover:bg-primary-700' 
                        : 'bg-charcoal-200 text-charcoal-500 cursor-not-allowed'
                    }`}
                    disabled={opportunity.status !== 'open'}
                  >
                    {opportunity.status === 'open' ? 'Invest Now' : 'Unavailable'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-20 bg-charcoal-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-charcoal-800 mb-4">
              Why Choose SAIR Trust
            </h2>
            <p className="text-xl text-charcoal-600">
              Experience the advantages of professional real estate investment management
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-sm text-center hover:shadow-md transition-shadow">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <TrendingUp className="w-8 h-8 text-primary-600" />
              </div>
              <h3 className="text-xl font-semibold text-charcoal-800 mb-4">High Returns</h3>
              <p className="text-charcoal-600">
                Target yields of 7-10% annually, significantly higher than traditional savings accounts or bonds.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-sm text-center hover:shadow-md transition-shadow">
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Shield className="w-8 h-8 text-emerald-600" />
              </div>
              <h3 className="text-xl font-semibold text-charcoal-800 mb-4">Lower Risk</h3>
              <p className="text-charcoal-600">
                Diversified portfolio across property types and markets reduces investment risk compared to single properties.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-sm text-center hover:shadow-md transition-shadow">
              <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Users className="w-8 h-8 text-yellow-600" />
              </div>
              <h3 className="text-xl font-semibold text-charcoal-800 mb-4">Professional Management</h3>
              <p className="text-charcoal-600">
                Expert team handles all aspects of property management, from acquisitions to tenant relations.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-sm text-center hover:shadow-md transition-shadow">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Calculator className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold text-charcoal-800 mb-4">Low Minimums</h3>
              <p className="text-charcoal-600">
                Start investing with as little as $1,000, making institutional-quality real estate accessible to everyone.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Educational Resources */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-charcoal-800 mb-4">
              Educational Resources
            </h2>
            <p className="text-xl text-charcoal-600">
              Learn more about real estate investing and make informed decisions
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-charcoal-50 p-8 rounded-xl">
              <h3 className="text-xl font-semibold text-charcoal-800 mb-4">REIT Basics</h3>
              <p className="text-charcoal-600 mb-6">
                Understanding Real Estate Investment Trusts, their benefits, and how they work.
              </p>
              <a href="#" className="flex items-center text-primary-600 font-medium hover:text-primary-700">
                Learn More <ArrowRight className="ml-2 w-4 h-4" />
              </a>
            </div>

            <div className="bg-charcoal-50 p-8 rounded-xl">
              <h3 className="text-xl font-semibold text-charcoal-800 mb-4">Tax Benefits</h3>
              <p className="text-charcoal-600 mb-6">
                How real estate investments can provide tax advantages and optimize your returns.
              </p>
              <a href="#" className="flex items-center text-primary-600 font-medium hover:text-primary-700">
                Learn More <ArrowRight className="ml-2 w-4 h-4" />
              </a>
            </div>

            <div className="bg-charcoal-50 p-8 rounded-xl">
              <h3 className="text-xl font-semibold text-charcoal-800 mb-4">Risk Management</h3>
              <p className="text-charcoal-600 mb-6">
                Understanding and managing risks in real estate investment portfolios.
              </p>
              <a href="#" className="flex items-center text-primary-600 font-medium hover:text-primary-700">
                Learn More <ArrowRight className="ml-2 w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default InvestPage;