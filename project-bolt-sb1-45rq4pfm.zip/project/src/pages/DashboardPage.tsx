import React, { useState } from 'react';
import { TrendingUp, DollarSign, Building, Calendar, Bell, FileText, MessageSquare, Download } from 'lucide-react';
import { mockInvestorPortfolio, properties } from '../data/mockData';

const DashboardPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  
  const portfolio = mockInvestorPortfolio;
  const totalReturnPercentage = ((portfolio.currentValue - portfolio.totalInvestment) / portfolio.totalInvestment) * 100;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const mockDividends = [
    { date: '2024-01-15', amount: 1850, property: 'Metropolitan Office Tower' },
    { date: '2023-12-15', amount: 1820, property: 'Sunset Shopping Center' },
    { date: '2023-11-15', amount: 1780, property: 'Harbor View Residences' },
  ];

  const mockNotifications = [
    { id: 1, type: 'dividend', message: 'January dividend payment processed', date: '2024-01-15', read: false },
    { id: 2, type: 'update', message: 'Metropolitan Office Tower renovation update', date: '2024-01-12', read: true },
    { id: 3, type: 'opportunity', message: 'New investment opportunity available', date: '2024-01-10', read: false },
  ];

  return (
    <div className="min-h-screen pt-16 bg-charcoal-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-charcoal-800 mb-2">
            Welcome back, John
          </h1>
          <p className="text-charcoal-600">
            Here's an overview of your real estate investment portfolio
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="bg-white rounded-lg shadow-sm mb-8">
          <div className="border-b border-charcoal-200">
            <nav className="flex space-x-8 px-6">
              {[
                { id: 'overview', name: 'Overview', icon: TrendingUp },
                { id: 'properties', name: 'Properties', icon: Building },
                { id: 'dividends', name: 'Dividends', icon: DollarSign },
                { id: 'documents', name: 'Documents', icon: FileText },
                { id: 'messages', name: 'Messages', icon: MessageSquare },
              ].map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center space-x-2 py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                      activeTab === tab.id
                        ? 'border-primary-600 text-primary-600'
                        : 'border-transparent text-charcoal-500 hover:text-charcoal-700 hover:border-charcoal-300'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{tab.name}</span>
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Tab Content */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            {/* Portfolio Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-medium text-charcoal-600">Total Investment</h3>
                  <DollarSign className="w-5 h-5 text-charcoal-400" />
                </div>
                <div className="text-2xl font-bold text-charcoal-800">
                  {formatCurrency(portfolio.totalInvestment)}
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-medium text-charcoal-600">Current Value</h3>
                  <TrendingUp className="w-5 h-5 text-emerald-500" />
                </div>
                <div className="text-2xl font-bold text-charcoal-800">
                  {formatCurrency(portfolio.currentValue)}
                </div>
                <div className="text-sm text-emerald-600 font-medium">
                  +{totalReturnPercentage.toFixed(1)}%
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-medium text-charcoal-600">Total Return</h3>
                  <TrendingUp className="w-5 h-5 text-emerald-500" />
                </div>
                <div className="text-2xl font-bold text-emerald-600">
                  {formatCurrency(portfolio.totalReturn)}
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-medium text-charcoal-600">Monthly Dividend</h3>
                  <Calendar className="w-5 h-5 text-primary-500" />
                </div>
                <div className="text-2xl font-bold text-charcoal-800">
                  {formatCurrency(portfolio.monthlyDividend)}
                </div>
                <div className="text-sm text-charcoal-500">
                  Next: Jan 15, 2024
                </div>
              </div>
            </div>

            {/* Performance Chart Placeholder */}
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <h3 className="text-lg font-semibold text-charcoal-800 mb-6">Portfolio Performance</h3>
              <div className="h-64 bg-gradient-to-r from-primary-50 to-emerald-50 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <TrendingUp className="w-12 h-12 text-primary-600 mx-auto mb-4" />
                  <p className="text-charcoal-600">Interactive performance chart would be displayed here</p>
                  <p className="text-sm text-charcoal-500 mt-2">12-month growth: +15.2%</p>
                </div>
              </div>
            </div>

            {/* Recent Activity & Notifications */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <h3 className="text-lg font-semibold text-charcoal-800 mb-4">Recent Dividends</h3>
                <div className="space-y-4">
                  {mockDividends.slice(0, 3).map((dividend, index) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-charcoal-50 rounded-lg">
                      <div>
                        <div className="font-medium text-charcoal-800">
                          {formatCurrency(dividend.amount)}
                        </div>
                        <div className="text-sm text-charcoal-600">
                          {new Date(dividend.date).toLocaleDateString()}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-charcoal-600">
                          {dividend.property}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-charcoal-800">Notifications</h3>
                  <Bell className="w-5 h-5 text-charcoal-400" />
                </div>
                <div className="space-y-3">
                  {mockNotifications.slice(0, 3).map((notification) => (
                    <div key={notification.id} className={`p-3 rounded-lg border-l-4 ${
                      notification.read ? 'bg-charcoal-50 border-charcoal-300' : 'bg-primary-50 border-primary-500'
                    }`}>
                      <div className="text-sm text-charcoal-800 font-medium">
                        {notification.message}
                      </div>
                      <div className="text-xs text-charcoal-500 mt-1">
                        {new Date(notification.date).toLocaleDateString()}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'properties' && (
          <div className="bg-white rounded-xl shadow-sm">
            <div className="p-6 border-b border-charcoal-200">
              <h3 className="text-lg font-semibold text-charcoal-800">Your Property Investments</h3>
            </div>
            <div className="p-6">
              <div className="space-y-6">
                {portfolio.properties.map((investment, index) => {
                  const property = properties.find(p => p.id === investment.propertyId);
                  if (!property) return null;
                  
                  return (
                    <div key={index} className="flex items-center justify-between p-4 border border-charcoal-200 rounded-lg hover:bg-charcoal-50 transition-colors">
                      <div className="flex items-center space-x-4">
                        <img 
                          src={property.images[0]} 
                          alt={property.name}
                          className="w-16 h-16 rounded-lg object-cover"
                        />
                        <div>
                          <h4 className="font-semibold text-charcoal-800">{property.name}</h4>
                          <p className="text-sm text-charcoal-600">
                            {property.location.city}, {property.location.state}
                          </p>
                          <p className="text-xs text-charcoal-500 capitalize">
                            {property.type} • {property.specifications.occupancyRate}% occupied
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold text-charcoal-800">
                          {formatCurrency(investment.currentValue)}
                        </div>
                        <div className="text-sm text-charcoal-600">
                          Investment: {formatCurrency(investment.investmentAmount)}
                        </div>
                        <div className="text-sm text-emerald-600 font-medium">
                          {investment.dividendYield}% yield
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'dividends' && (
          <div className="bg-white rounded-xl shadow-sm">
            <div className="p-6 border-b border-charcoal-200">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold text-charcoal-800">Dividend History</h3>
                <button className="flex items-center space-x-2 text-primary-600 hover:text-primary-700">
                  <Download className="w-4 h-4" />
                  <span className="text-sm">Export</span>
                </button>
              </div>
            </div>
            <div className="p-6">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-charcoal-200">
                      <th className="text-left py-3 px-4 font-medium text-charcoal-600">Date</th>
                      <th className="text-left py-3 px-4 font-medium text-charcoal-600">Property</th>
                      <th className="text-right py-3 px-4 font-medium text-charcoal-600">Amount</th>
                      <th className="text-right py-3 px-4 font-medium text-charcoal-600">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockDividends.map((dividend, index) => (
                      <tr key={index} className="border-b border-charcoal-100">
                        <td className="py-3 px-4 text-charcoal-800">
                          {new Date(dividend.date).toLocaleDateString()}
                        </td>
                        <td className="py-3 px-4 text-charcoal-800">
                          {dividend.property}
                        </td>
                        <td className="py-3 px-4 text-right font-semibold text-charcoal-800">
                          {formatCurrency(dividend.amount)}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <span className="px-2 py-1 bg-emerald-100 text-emerald-800 text-xs rounded-full">
                            Paid
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'documents' && (
          <div className="bg-white rounded-xl shadow-sm">
            <div className="p-6 border-b border-charcoal-200">
              <h3 className="text-lg font-semibold text-charcoal-800">Document Vault</h3>
            </div>
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[
                  { name: 'Q4 2023 Statement', type: 'PDF', date: '2024-01-05', size: '1.2 MB' },
                  { name: 'Tax Document 1099', type: 'PDF', date: '2024-01-31', size: '0.8 MB' },
                  { name: 'Investment Agreement', type: 'PDF', date: '2023-03-15', size: '2.1 MB' },
                  { name: 'Property Brochures', type: 'ZIP', date: '2023-12-20', size: '15.3 MB' },
                  { name: 'Annual Report 2023', type: 'PDF', date: '2024-01-20', size: '5.7 MB' },
                  { name: 'Dividend Schedule', type: 'PDF', date: '2024-01-01', size: '0.5 MB' },
                ].map((doc, index) => (
                  <div key={index} className="border border-charcoal-200 rounded-lg p-4 hover:bg-charcoal-50 transition-colors cursor-pointer">
                    <div className="flex items-center justify-between mb-2">
                      <FileText className="w-8 h-8 text-primary-600" />
                      <span className="text-xs text-charcoal-500">{doc.type}</span>
                    </div>
                    <h4 className="font-medium text-charcoal-800 mb-1">{doc.name}</h4>
                    <p className="text-sm text-charcoal-600">{doc.date}</p>
                    <p className="text-xs text-charcoal-500">{doc.size}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'messages' && (
          <div className="bg-white rounded-xl shadow-sm">
            <div className="p-6 border-b border-charcoal-200">
              <h3 className="text-lg font-semibold text-charcoal-800">Messages</h3>
            </div>
            <div className="p-6">
              <div className="text-center py-12">
                <MessageSquare className="w-16 h-16 text-charcoal-300 mx-auto mb-4" />
                <h4 className="text-lg font-medium text-charcoal-800 mb-2">No messages</h4>
                <p className="text-charcoal-600 mb-6">
                  You're all caught up! We'll notify you when you receive new messages.
                </p>
                <button className="bg-primary-600 text-white px-6 py-2 rounded-lg hover:bg-primary-700 transition-colors">
                  Contact Support
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DashboardPage;