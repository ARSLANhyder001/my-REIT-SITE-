import React, { useState } from 'react';
import { Calendar, User, ArrowRight, Search } from 'lucide-react';
import { newsArticles } from '../data/mockData';

const NewsPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = ['all', 'Acquisitions', 'Performance', 'Market Analysis', 'Company News'];

  const filteredArticles = newsArticles.filter((article) => {
    const matchesSearch = article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         article.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || article.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  // Extended mock articles for demonstration
  const allArticles = [
    ...newsArticles,
    {
      id: '3',
      title: 'SAIR Trust Announces Strategic Partnership with Green Building Council',
      excerpt: 'New partnership emphasizes our commitment to sustainable real estate development.',
      content: 'Full article content...',
      author: 'Sustainability Team',
      publishedAt: '2024-01-08',
      category: 'Company News',
      image: 'https://images.pexels.com/photos/1181354/pexels-photo-1181354.jpeg'
    },
    {
      id: '4',
      title: 'Commercial Real Estate Market Outlook 2024',
      excerpt: 'Expert analysis on market trends and opportunities in the coming year.',
      content: 'Full article content...',
      author: 'Research Team',
      publishedAt: '2024-01-05',
      category: 'Market Analysis',
      image: 'https://images.pexels.com/photos/1647976/pexels-photo-1647976.jpeg'
    },
    {
      id: '5',
      title: 'Record-Breaking Occupancy Rates Across Portfolio',
      excerpt: 'Strong leasing activity drives portfolio occupancy to all-time highs.',
      content: 'Full article content...',
      author: 'Asset Management',
      publishedAt: '2024-01-03',
      category: 'Performance',
      image: 'https://images.pexels.com/photos/1181396/pexels-photo-1181396.jpeg'
    },
    {
      id: '6',
      title: 'New Industrial Development Breaks Ground in Phoenix',
      excerpt: 'Construction begins on our latest logistics facility in Arizona.',
      content: 'Full article content...',
      author: 'Development Team',
      publishedAt: '2023-12-28',
      category: 'Acquisitions',
      image: 'https://images.pexels.com/photos/1643384/pexels-photo-1643384.jpeg'
    }
  ];

  const filteredAllArticles = allArticles.filter((article) => {
    const matchesSearch = article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         article.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || article.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-charcoal-800 to-charcoal-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              News & Insights
            </h1>
            <p className="text-xl text-charcoal-200 max-w-3xl mx-auto">
              Stay informed with the latest market trends, company updates, and real estate insights
            </p>
          </div>
        </div>
      </section>

      {/* Featured Article */}
      {allArticles.length > 0 && (
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-charcoal-800 mb-2">Featured Story</h2>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="relative overflow-hidden rounded-xl">
                <img 
                  src={allArticles[0].image} 
                  alt={allArticles[0].title}
                  className="w-full h-80 object-cover hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-6 left-6">
                  <span className="bg-primary-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                    {allArticles[0].category}
                  </span>
                </div>
              </div>
              <div>
                <div className="flex items-center space-x-4 mb-4 text-sm text-charcoal-500">
                  <div className="flex items-center">
                    <Calendar className="w-4 h-4 mr-2" />
                    {new Date(allArticles[0].publishedAt).toLocaleDateString()}
                  </div>
                  <div className="flex items-center">
                    <User className="w-4 h-4 mr-2" />
                    {allArticles[0].author}
                  </div>
                </div>
                <h3 className="text-3xl font-bold text-charcoal-800 mb-4 leading-tight">
                  {allArticles[0].title}
                </h3>
                <p className="text-lg text-charcoal-600 mb-6 leading-relaxed">
                  {allArticles[0].excerpt}
                </p>
                <button className="flex items-center text-primary-600 hover:text-primary-700 font-semibold group">
                  Read Full Article
                  <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Search and Filter */}
      <section className="py-8 bg-charcoal-50 border-y">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-charcoal-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search articles..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-charcoal-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              />
            </div>
            
            <div className="flex items-center space-x-4">
              <span className="text-sm text-charcoal-600">Filter by:</span>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-2 border border-charcoal-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              >
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category === 'all' ? 'All Categories' : category}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </section>

      {/* Articles Grid */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {filteredAllArticles.length > 1 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredAllArticles.slice(1).map((article) => (
                <article key={article.id} className="bg-white border border-charcoal-200 rounded-xl overflow-hidden hover:shadow-lg transition-all duration-300 group cursor-pointer">
                  <div className="relative overflow-hidden">
                    <img 
                      src={article.image} 
                      alt={article.title}
                      className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-4 left-4">
                      <span className="bg-white/90 backdrop-blur-sm text-charcoal-800 px-3 py-1 rounded-full text-xs font-medium">
                        {article.category}
                      </span>
                    </div>
                  </div>
                  
                  <div className="p-6">
                    <div className="flex items-center space-x-4 mb-3 text-xs text-charcoal-500">
                      <div className="flex items-center">
                        <Calendar className="w-3 h-3 mr-1" />
                        {new Date(article.publishedAt).toLocaleDateString()}
                      </div>
                      <div className="flex items-center">
                        <User className="w-3 h-3 mr-1" />
                        {article.author}
                      </div>
                    </div>
                    
                    <h3 className="text-lg font-semibold text-charcoal-800 mb-3 group-hover:text-primary-600 transition-colors line-clamp-2">
                      {article.title}
                    </h3>
                    
                    <p className="text-charcoal-600 mb-4 text-sm leading-relaxed line-clamp-3">
                      {article.excerpt}
                    </p>
                    
                    <div className="flex items-center justify-between">
                      <button className="text-primary-600 hover:text-primary-700 font-medium text-sm flex items-center group">
                        Read More
                        <ArrowRight className="ml-1 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                      </button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <Search className="w-16 h-16 text-charcoal-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-charcoal-800 mb-2">
                No articles found
              </h3>
              <p className="text-charcoal-600">
                Try adjusting your search terms or filters to see more results.
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-16 bg-primary-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-white mb-4">
              Stay Updated
            </h2>
            <p className="text-xl text-primary-100 mb-8 max-w-2xl mx-auto">
              Subscribe to our newsletter for the latest market insights and company updates
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-3 rounded-lg border-0 focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-primary-600"
              />
              <button className="bg-white text-primary-600 px-6 py-3 rounded-lg font-semibold hover:bg-primary-50 transition-colors">
                Subscribe
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Market Insights */}
      <section className="py-16 bg-charcoal-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-charcoal-800 mb-4">
              Market Insights
            </h2>
            <p className="text-xl text-charcoal-600">
              Key metrics and trends shaping the commercial real estate market
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-sm text-center">
              <div className="text-3xl font-bold text-primary-600 mb-2">4.2%</div>
              <div className="text-charcoal-600 font-medium mb-2">Cap Rate Average</div>
              <div className="text-sm text-emerald-600">↑ 0.3% from last quarter</div>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-sm text-center">
              <div className="text-3xl font-bold text-emerald-600 mb-2">92%</div>
              <div className="text-charcoal-600 font-medium mb-2">National Occupancy</div>
              <div className="text-sm text-emerald-600">↑ 1.2% from last quarter</div>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-sm text-center">
              <div className="text-3xl font-bold text-yellow-600 mb-2">$2.8T</div>
              <div className="text-charcoal-600 font-medium mb-2">Market Size</div>
              <div className="text-sm text-emerald-600">↑ 5.1% YoY growth</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default NewsPage;