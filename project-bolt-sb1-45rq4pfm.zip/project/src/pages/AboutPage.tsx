import React from 'react';
import { Award, Users, TrendingUp, Shield } from 'lucide-react';
import { teamMembers } from '../data/mockData';

const AboutPage: React.FC = () => {
  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-primary-600 to-primary-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              About SAIR Trust
            </h1>
            <p className="text-xl text-primary-100 max-w-3xl mx-auto">
              Building the future of real estate investment through innovation, 
              transparency, and unwavering commitment to our investors.
            </p>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-charcoal-800 mb-6">
                Our Story & Mission
              </h2>
              <div className="space-y-6 text-charcoal-600 leading-relaxed">
                <p>
                  Founded in 2010, SAIR Trust emerged from a simple yet powerful vision: 
                  to democratize access to institutional-quality real estate investments. 
                  What started as a small team of passionate real estate professionals 
                  has grown into one of the most trusted REITs in North America.
                </p>
                <p>
                  Our mission is to provide individual investors with the opportunity to 
                  participate in premium commercial real estate markets that were traditionally 
                  accessible only to large institutions. Through careful selection, expert 
                  management, and transparent operations, we've built a portfolio that 
                  consistently delivers strong returns while preserving capital.
                </p>
                <p>
                  Today, we manage over $2.8 billion in assets across 127 properties, 
                  serving thousands of investors who trust us with their financial future. 
                  Our commitment to sustainability, community impact, and long-term value 
                  creation guides every decision we make.
                </p>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://images.pexels.com/photos/416405/pexels-photo-416405.jpeg" 
                alt="Modern office building" 
                className="w-full h-96 object-cover rounded-xl shadow-lg"
              />
              <div className="absolute -bottom-6 -left-6 bg-primary-600 text-white p-6 rounded-lg shadow-lg">
                <div className="text-2xl font-bold">14+</div>
                <div className="text-sm">Years of Excellence</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-charcoal-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-charcoal-800 mb-4">
              Our Core Values
            </h2>
            <p className="text-xl text-charcoal-600 max-w-3xl mx-auto">
              The principles that guide our investment decisions and shape our company culture
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center mb-4">
                <TrendingUp className="w-6 h-6 text-primary-600" />
              </div>
              <h3 className="text-xl font-semibold text-charcoal-800 mb-3">Performance</h3>
              <p className="text-charcoal-600">
                Delivering consistent, market-leading returns through disciplined investment strategies.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mb-4">
                <Shield className="w-6 h-6 text-emerald-600" />
              </div>
              <h3 className="text-xl font-semibold text-charcoal-800 mb-3">Integrity</h3>
              <p className="text-charcoal-600">
                Operating with complete transparency and maintaining the highest ethical standards.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center mb-4">
                <Users className="w-6 h-6 text-yellow-600" />
              </div>
              <h3 className="text-xl font-semibold text-charcoal-800 mb-3">Partnership</h3>
              <p className="text-charcoal-600">
                Building long-term relationships based on trust, communication, and shared success.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                <Award className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold text-charcoal-800 mb-3">Excellence</h3>
              <p className="text-charcoal-600">
                Pursuing excellence in every aspect of property management and investor relations.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Leadership Team */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-charcoal-800 mb-4">
              Leadership Team
            </h2>
            <p className="text-xl text-charcoal-600 max-w-3xl mx-auto">
              Meet the experienced professionals driving SAIR Trust's success
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {teamMembers.map((member) => (
              <div key={member.id} className="bg-charcoal-50 rounded-xl p-8 text-center hover:shadow-lg transition-shadow">
                <img 
                  src={member.image} 
                  alt={member.name}
                  className="w-24 h-24 rounded-full mx-auto mb-6 object-cover"
                />
                <h3 className="text-xl font-semibold text-charcoal-800 mb-2">
                  {member.name}
                </h3>
                <p className="text-primary-600 font-medium mb-4">
                  {member.position}
                </p>
                <p className="text-charcoal-600 leading-relaxed">
                  {member.bio}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Investment Philosophy */}
      <section className="py-20 bg-charcoal-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <img 
                src="https://images.pexels.com/photos/590041/pexels-photo-590041.jpeg" 
                alt="Investment strategy meeting" 
                className="w-full h-96 object-cover rounded-xl shadow-lg"
              />
            </div>
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-charcoal-800 mb-6">
                Investment Philosophy
              </h2>
              <div className="space-y-6 text-charcoal-600 leading-relaxed">
                <p>
                  Our investment approach is built on three fundamental pillars: 
                  diversification, quality, and long-term value creation. We believe 
                  that sustainable returns come from owning high-quality properties 
                  in growing markets with strong fundamentals.
                </p>
                <p>
                  We focus on income-generating commercial properties across multiple 
                  sectors and geographic regions. Our rigorous due diligence process 
                  ensures that every acquisition meets our strict criteria for 
                  location, tenant quality, and growth potential.
                </p>
                <p>
                  Risk management is at the core of everything we do. Through careful 
                  portfolio construction, active management, and continuous monitoring, 
                  we work to protect investor capital while maximizing returns.
                </p>
              </div>
              
              <div className="mt-8 space-y-4">
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-primary-600 rounded-full mr-3"></div>
                  <span className="text-charcoal-700">Strategic asset allocation across property types</span>
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-primary-600 rounded-full mr-3"></div>
                  <span className="text-charcoal-700">Focus on growing metropolitan markets</span>
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-primary-600 rounded-full mr-3"></div>
                  <span className="text-charcoal-700">Active property management and optimization</span>
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-primary-600 rounded-full mr-3"></div>
                  <span className="text-charcoal-700">Environmental and social responsibility</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ESG Commitment */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-charcoal-800 mb-4">
              ESG Commitment
            </h2>
            <p className="text-xl text-charcoal-600 max-w-3xl mx-auto">
              Environmental stewardship, social responsibility, and strong governance 
              are integral to our business model
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-8">
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-emerald-600">E</span>
              </div>
              <h3 className="text-xl font-semibold text-charcoal-800 mb-4">Environmental</h3>
              <p className="text-charcoal-600">
                Implementing energy-efficient systems, sustainable building practices, 
                and carbon reduction initiatives across our portfolio.
              </p>
            </div>
            
            <div className="text-center p-8">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-primary-600">S</span>
              </div>
              <h3 className="text-xl font-semibold text-charcoal-800 mb-4">Social</h3>
              <p className="text-charcoal-600">
                Supporting local communities, promoting diversity and inclusion, 
                and creating positive social impact through our investments.
              </p>
            </div>
            
            <div className="text-center p-8">
              <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-yellow-600">G</span>
              </div>
              <h3 className="text-xl font-semibold text-charcoal-800 mb-4">Governance</h3>
              <p className="text-charcoal-600">
                Maintaining the highest standards of corporate governance, 
                transparency, and accountability to all stakeholders.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;