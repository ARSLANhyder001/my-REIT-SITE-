import React from 'react';
import { MapPin, Building, TrendingUp } from 'lucide-react';
import { Property } from '../../types';

interface PropertyCardProps {
  property: Property;
  onClick?: () => void;
}

const PropertyCard: React.FC<PropertyCardProps> = ({ property, onClick }) => {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      notation: 'compact'
    }).format(amount);
  };

  return (
    <div 
      className="bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 overflow-hidden cursor-pointer group"
      onClick={onClick}
    >
      <div className="relative overflow-hidden">
        <img 
          src={property.images[0]} 
          alt={property.name}
          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-4 left-4">
          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
            property.status === 'active' ? 'bg-emerald-100 text-emerald-800' :
            property.status === 'development' ? 'bg-yellow-100 text-yellow-800' :
            'bg-blue-100 text-blue-800'
          }`}>
            {property.status.charAt(0).toUpperCase() + property.status.slice(1)}
          </span>
        </div>
      </div>
      
      <div className="p-6">
        <div className="flex items-start justify-between mb-3">
          <h3 className="text-lg font-semibold text-charcoal-800 group-hover:text-primary-600 transition-colors">
            {property.name}
          </h3>
          <span className="text-xs uppercase font-medium text-charcoal-500 bg-charcoal-100 px-2 py-1 rounded">
            {property.type}
          </span>
        </div>
        
        <div className="flex items-center text-charcoal-600 mb-4">
          <MapPin className="w-4 h-4 mr-2" />
          <span className="text-sm">{property.location.city}, {property.location.state}</span>
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="flex items-center">
            <Building className="w-4 h-4 text-charcoal-500 mr-2" />
            <div>
              <p className="text-xs text-charcoal-500">Area</p>
              <p className="text-sm font-medium">{property.specifications.totalArea.toLocaleString()} sq ft</p>
            </div>
          </div>
          <div className="flex items-center">
            <TrendingUp className="w-4 h-4 text-emerald-500 mr-2" />
            <div>
              <p className="text-xs text-charcoal-500">Yield</p>
              <p className="text-sm font-medium text-emerald-600">{property.financial.annualYield}%</p>
            </div>
          </div>
        </div>
        
        <div className="flex justify-between items-center pt-4 border-t border-charcoal-100">
          <div>
            <p className="text-xs text-charcoal-500">Current Value</p>
            <p className="text-lg font-semibold text-charcoal-800">
              {formatCurrency(property.financial.currentValue)}
            </p>
          </div>
          <div className="text-right">
            <p className="text-xs text-charcoal-500">Occupancy</p>
            <p className="text-sm font-medium">{property.specifications.occupancyRate}%</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyCard;