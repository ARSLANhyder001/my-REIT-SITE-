export interface Property {
  id: string;
  name: string;
  type: 'office' | 'retail' | 'residential' | 'industrial' | 'mixed-use';
  location: {
    address: string;
    city: string;
    state: string;
    country: string;
    coordinates: { lat: number; lng: number };
  };
  images: string[];
  specifications: {
    totalArea: number;
    occupancyRate: number;
    yearBuilt: number;
    floors: number;
  };
  financial: {
    acquisitionPrice: number;
    currentValue: number;
    monthlyRent: number;
    annualYield: number;
  };
  status: 'active' | 'development' | 'completed';
  description: string;
}

export interface InvestmentOpportunity {
  id: string;
  title: string;
  description: string;
  targetAmount: number;
  raisedAmount: number;
  minimumInvestment: number;
  projectedYield: number;
  timeline: string;
  riskLevel: 'low' | 'medium' | 'high';
  status: 'open' | 'closed' | 'coming-soon';
}

export interface NewsArticle {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  publishedAt: string;
  category: string;
  image: string;
}

export interface TeamMember {
  id: string;
  name: string;
  position: string;
  bio: string;
  image: string;
  linkedin?: string;
}

export interface InvestorPortfolio {
  totalInvestment: number;
  currentValue: number;
  totalReturn: number;
  monthlyDividend: number;
  properties: Array<{
    propertyId: string;
    investmentAmount: number;
    currentValue: number;
    dividendYield: number;
  }>;
}