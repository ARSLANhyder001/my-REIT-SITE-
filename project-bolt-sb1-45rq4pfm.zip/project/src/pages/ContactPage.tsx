import React, { useState } from 'react';
import { Mail, Phone, MapPin, Clock, Send, MessageSquare } from 'lucide-react';

const ContactPage: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
    inquiryType: 'general'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', formData);
    // Reset form
    setFormData({
      name: '',
      email: '',
      phone: '',
      subject: '',
      message: '',
      inquiryType: 'general'
    });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-primary-600 to-primary-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Contact Us
            </h1>
            <p className="text-xl text-primary-100 max-w-3xl mx-auto">
              Get in touch with our team of real estate investment experts. 
              We're here to help you achieve your financial goals.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Phone className="w-8 h-8 text-primary-600" />
              </div>
              <h3 className="text-lg font-semibold text-charcoal-800 mb-2">Phone</h3>
              <p className="text-charcoal-600 mb-2">General Inquiries</p>
              <p className="text-primary-600 font-medium">+1 (555) 123-4567</p>
              <p className="text-charcoal-600 mb-2 mt-4">Investor Relations</p>
              <p className="text-primary-600 font-medium">+1 (555) 123-4568</p>
            </div>

            <div className="text-center p-6">
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Mail className="w-8 h-8 text-emerald-600" />
              </div>
              <h3 className="text-lg font-semibold text-charcoal-800 mb-2">Email</h3>
              <p className="text-charcoal-600 mb-2">General</p>
              <p className="text-emerald-600 font-medium">info@sairtrust.com</p>
              <p className="text-charcoal-600 mb-2 mt-4">Investors</p>
              <p className="text-emerald-600 font-medium">investors@sairtrust.com</p>
            </div>

            <div className="text-center p-6">
              <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-8 h-8 text-yellow-600" />
              </div>
              <h3 className="text-lg font-semibold text-charcoal-800 mb-2">Address</h3>
              <p className="text-charcoal-600">
                1250 Broadway, Suite 2700<br />
                New York, NY 10001<br />
                United States
              </p>
            </div>

            <div className="text-center p-6">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-lg font-semibold text-charcoal-800 mb-2">Hours</h3>
              <p className="text-charcoal-600">
                Monday - Friday<br />
                9:00 AM - 6:00 PM EST<br />
                <span className="text-sm">Closed weekends</span>
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Form & Map */}
      <section className="py-16 bg-charcoal-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div className="bg-white rounded-xl shadow-lg p-8">
              <div className="mb-8">
                <h2 className="text-2xl font-bold text-charcoal-800 mb-2">
                  Send us a Message
                </h2>
                <p className="text-charcoal-600">
                  Fill out the form below and we'll get back to you within 24 hours.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-charcoal-700 mb-2">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-charcoal-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      placeholder="John Doe"
                    />
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-charcoal-700 mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-charcoal-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      placeholder="john@example.com"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-charcoal-700 mb-2">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-charcoal-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      placeholder="+1 (555) 123-4567"
                    />
                  </div>

                  <div>
                    <label htmlFor="inquiryType" className="block text-sm font-medium text-charcoal-700 mb-2">
                      Inquiry Type
                    </label>
                    <select
                      id="inquiryType"
                      name="inquiryType"
                      value={formData.inquiryType}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-charcoal-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    >
                      <option value="general">General Inquiry</option>
                      <option value="investment">Investment Opportunity</option>
                      <option value="support">Investor Support</option>
                      <option value="partnership">Partnership</option>
                      <option value="media">Media Inquiry</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label htmlFor="subject" className="block text-sm font-medium text-charcoal-700 mb-2">
                    Subject *
                  </label>
                  <input
                    type="text"
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-charcoal-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    placeholder="How can we help you?"
                  />
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-charcoal-700 mb-2">
                    Message *
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={6}
                    className="w-full px-4 py-3 border border-charcoal-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent resize-none"
                    placeholder="Please provide details about your inquiry..."
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-primary-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-primary-700 transition-colors flex items-center justify-center"
                >
                  <Send className="w-5 h-5 mr-2" />
                  Send Message
                </button>
              </form>
            </div>

            {/* Map & Office Info */}
            <div className="space-y-8">
              {/* Map Placeholder */}
              <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                <div className="h-64 bg-gradient-to-br from-primary-100 to-primary-200 flex items-center justify-center">
                  <div className="text-center">
                    <MapPin className="w-16 h-16 text-primary-600 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-charcoal-800 mb-2">
                      Our Location
                    </h3>
                    <p className="text-charcoal-600">
                      Interactive map would be embedded here
                    </p>
                  </div>
                </div>
                <div className="p-6">
                  <h4 className="font-semibold text-charcoal-800 mb-2">SAIR Trust Headquarters</h4>
                  <p className="text-charcoal-600 text-sm">
                    Located in the heart of Manhattan's Financial District, 
                    our offices are easily accessible by public transportation.
                  </p>
                </div>
              </div>

              {/* Quick Contact Options */}
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-lg font-semibold text-charcoal-800 mb-4">
                  Need Immediate Assistance?
                </h3>
                <div className="space-y-4">
                  <div className="flex items-center p-4 bg-primary-50 rounded-lg hover:bg-primary-100 transition-colors cursor-pointer">
                    <MessageSquare className="w-6 h-6 text-primary-600 mr-3" />
                    <div>
                      <div className="font-medium text-charcoal-800">Live Chat</div>
                      <div className="text-sm text-charcoal-600">Available 9 AM - 6 PM EST</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center p-4 bg-emerald-50 rounded-lg hover:bg-emerald-100 transition-colors cursor-pointer">
                    <Phone className="w-6 h-6 text-emerald-600 mr-3" />
                    <div>
                      <div className="font-medium text-charcoal-800">Schedule a Call</div>
                      <div className="text-sm text-charcoal-600">Book a consultation</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center p-4 bg-yellow-50 rounded-lg hover:bg-yellow-100 transition-colors cursor-pointer">
                    <Mail className="w-6 h-6 text-yellow-600 mr-3" />
                    <div>
                      <div className="font-medium text-charcoal-800">Email Support</div>
                      <div className="text-sm text-charcoal-600">Response within 24 hours</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* FAQ Link */}
              <div className="bg-charcoal-800 text-white rounded-xl p-6">
                <h3 className="text-lg font-semibold mb-2">
                  Frequently Asked Questions
                </h3>
                <p className="text-charcoal-200 mb-4 text-sm">
                  Find answers to common questions about investing with SAIR Trust.
                </p>
                <button className="bg-white text-charcoal-800 px-4 py-2 rounded-lg text-sm font-medium hover:bg-charcoal-100 transition-colors">
                  View FAQ
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Office Locations */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-charcoal-800 mb-4">
              Our Offices
            </h2>
            <p className="text-xl text-charcoal-600">
              Visit us at one of our convenient locations
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6 border border-charcoal-200 rounded-xl hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-6 h-6 text-primary-600" />
              </div>
              <h3 className="text-lg font-semibold text-charcoal-800 mb-2">New York (HQ)</h3>
              <p className="text-charcoal-600 text-sm mb-4">
                1250 Broadway, Suite 2700<br />
                New York, NY 10001
              </p>
              <p className="text-primary-600 font-medium text-sm">+1 (555) 123-4567</p>
            </div>

            <div className="text-center p-6 border border-charcoal-200 rounded-xl hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-6 h-6 text-emerald-600" />
              </div>
              <h3 className="text-lg font-semibold text-charcoal-800 mb-2">Los Angeles</h3>
              <p className="text-charcoal-600 text-sm mb-4">
                1900 Avenue of the Stars<br />
                Los Angeles, CA 90067
              </p>
              <p className="text-emerald-600 font-medium text-sm">+1 (555) 123-4569</p>
            </div>

            <div className="text-center p-6 border border-charcoal-200 rounded-xl hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-6 h-6 text-yellow-600" />
              </div>
              <h3 className="text-lg font-semibold text-charcoal-800 mb-2">Chicago</h3>
              <p className="text-charcoal-600 text-sm mb-4">
                233 S Wacker Dr, Suite 4500<br />
                Chicago, IL 60606
              </p>
              <p className="text-yellow-600 font-medium text-sm">+1 (555) 123-4570</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;