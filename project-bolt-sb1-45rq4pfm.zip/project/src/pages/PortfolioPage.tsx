import React, { useState } from 'react';
import { MapPin, Search, Filter, Building, TrendingUp } from 'lucide-react';
import PropertyCard from '../components/UI/PropertyCard';
import { properties } from '../data/mockData';
import { Property } from '../types';

const PortfolioPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [showMap, setShowMap] = useState(false);

  const propertyTypes = ['all', 'office', 'retail', 'residential', 'industrial', 'mixed-use'];
  const propertyStatuses = ['all', 'active', 'development', 'completed'];

  const filteredProperties = properties.filter((property) => {
    const matchesSearch = property.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         property.location.city.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === 'all' || property.type === selectedType;
    const matchesStatus = selectedStatus === 'all' || property.status === selectedStatus;
    
    return matchesSearch && matchesType && matchesStatus;
  });

  const totalValue = properties.reduce((sum, property) => sum + property.financial.currentValue, 0);
  const avgYield = properties.reduce((sum, property) => sum + property.financial.annualYield, 0) / properties.length;
  const avgOccupancy = properties.reduce((sum, property) => sum + property.specifications.occupancyRate, 0) / properties.length;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      notation: 'compact'
    }).format(amount);
  };

  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-charcoal-800 to-charcoal-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Our Portfolio
            </h1>
            <p className="text-xl text-charcoal-200 max-w-3xl mx-auto">
              A diversified collection of premium commercial properties across North America
            </p>
          </div>
        </div>
      </section>

      {/* Portfolio Stats */}
      <section className="py-16 bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary-600 mb-2">
                {formatCurrency(totalValue)}
              </div>
              <p className="text-charcoal-600">Total Portfolio Value</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-emerald-600 mb-2">
                {avgYield.toFixed(1)}%
              </div>
              <p className="text-charcoal-600">Average Yield</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-yellow-600 mb-2">
                {properties.length}
              </div>
              <p className="text-charcoal-600">Properties</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600 mb-2">
                {avgOccupancy.toFixed(0)}%
              </div>
              <p className="text-charcoal-600">Avg Occupancy</p>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive Map Toggle */}
      <section className="py-8 bg-charcoal-50 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-center">
            <div className="bg-white rounded-lg p-1 shadow-sm">
              <button
                onClick={() => setShowMap(false)}
                className={`px-6 py-2 rounded-md text-sm font-medium transition-colors ${
                  !showMap 
                    ? 'bg-primary-600 text-white' 
                    : 'text-charcoal-600 hover:text-primary-600'
                }`}
              >
                List View
              </button>
              <button
                onClick={() => setShowMap(true)}
                className={`px-6 py-2 rounded-md text-sm font-medium transition-colors ${
                  showMap 
                    ? 'bg-primary-600 text-white' 
                    : 'text-charcoal-600 hover:text-primary-600'
                }`}
              >
                Map View
              </button>
            </div>
          </div>
        </div>
      </section>

      {showMap ? (
        /* Map View */
        <section className="py-16 bg-charcoal-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="h-96 bg-gradient-to-br from-primary-100 to-primary-200 flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="w-16 h-16 text-primary-600 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-charcoal-800 mb-2">
                    Interactive Property Map
                  </h3>
                  <p className="text-charcoal-600">
                    Map integration would display all properties with clickable markers
                  </p>
                  <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4 max-w-2xl mx-auto">
                    {properties.slice(0, 3).map((property) => (
                      <div key={property.id} className="bg-white p-4 rounded-lg shadow-sm">
                        <div className="flex items-center space-x-2 mb-2">
                          <div className="w-3 h-3 bg-primary-600 rounded-full"></div>
                          <span className="text-sm font-medium text-charcoal-800">{property.name}</span>
                        </div>
                        <p className="text-xs text-charcoal-600">
                          {property.location.city}, {property.location.state}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      ) : (
        /* List View */
        <>
          {/* Filters */}
          <section className="py-8 bg-charcoal-50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="bg-white rounded-xl shadow-sm p-6">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  {/* Search */}
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-charcoal-400 w-5 h-5" />
                    <input
                      type="text"
                      placeholder="Search properties..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 border border-charcoal-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    />
                  </div>

                  {/* Property Type Filter */}
                  <div className="relative">
                    <select
                      value={selectedType}
                      onChange={(e) => setSelectedType(e.target.value)}
                      className="w-full px-4 py-2 border border-charcoal-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent appearance-none bg-white"
                    >
                      {propertyTypes.map((type) => (
                        <option key={type} value={type}>
                          {type === 'all' ? 'All Types' : type.charAt(0).toUpperCase() + type.slice(1)}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Status Filter */}
                  <div className="relative">
                    <select
                      value={selectedStatus}
                      onChange={(e) => setSelectedStatus(e.target.value)}
                      className="w-full px-4 py-2 border border-charcoal-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent appearance-none bg-white"
                    >
                      {propertyStatuses.map((status) => (
                        <option key={status} value={status}>
                          {status === 'all' ? 'All Status' : status.charAt(0).toUpperCase() + status.slice(1)}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Results Count */}
                  <div className="flex items-center justify-center md:justify-start">
                    <span className="text-sm text-charcoal-600">
                      {filteredProperties.length} properties found
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Properties Grid */}
          <section className="py-16 bg-white">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              {filteredProperties.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {filteredProperties.map((property) => (
                    <PropertyCard 
                      key={property.id} 
                      property={property}
                      onClick={() => {/* Navigate to property detail */}}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-16">
                  <Building className="w-16 h-16 text-charcoal-300 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-charcoal-800 mb-2">
                    No properties found
                  </h3>
                  <p className="text-charcoal-600">
                    Try adjusting your filters to see more results.
                  </p>
                </div>
              )}
            </div>
          </section>
        </>
      )}

      {/* Property Performance Summary */}
      <section className="py-16 bg-charcoal-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-charcoal-800 mb-4">
              Portfolio Performance
            </h2>
            <p className="text-xl text-charcoal-600">
              Consistent returns across diverse property types and markets
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-charcoal-800">By Property Type</h3>
                <TrendingUp className="w-5 h-5 text-emerald-500" />
              </div>
              <div className="space-y-3">
                {['Office', 'Retail', 'Residential', 'Industrial'].map((type, index) => (
                  <div key={type} className="flex justify-between items-center">
                    <span className="text-charcoal-600">{type}</span>
                    <span className="font-semibold text-charcoal-800">
                      {(7.2 + index * 0.3).toFixed(1)}%
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-charcoal-800">Geographic Spread</h3>
                <MapPin className="w-5 h-5 text-primary-500" />
              </div>
              <div className="space-y-3">
                {['Northeast', 'Southeast', 'West Coast', 'Midwest'].map((region, index) => (
                  <div key={region} className="flex justify-between items-center">
                    <span className="text-charcoal-600">{region}</span>
                    <span className="font-semibold text-charcoal-800">
                      {25 + index * 5}%
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-charcoal-800">Key Metrics</h3>
                <Building className="w-5 h-5 text-yellow-500" />
              </div>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-charcoal-600">Avg. Property Age</span>
                  <span className="font-semibold text-charcoal-800">12 years</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-charcoal-600">Avg. Lease Term</span>
                  <span className="font-semibold text-charcoal-800">7.2 years</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-charcoal-600">Tenant Retention</span>
                  <span className="font-semibold text-charcoal-800">89%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-charcoal-600">NOI Growth</span>
                  <span className="font-semibold text-emerald-600">+4.2%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default PortfolioPage;