import { Property, InvestmentOpportunity, NewsArticle, TeamMember, InvestorPortfolio } from '../types';

export const kpiData = {
  totalAssets: 2.8e9, // $2.8B
  averageYield: 8.2,
  propertiesOwned: 127,
  investorGrowth: 24.5
};

export const properties: Property[] = [
  {
    id: '1',
    name: 'Metropolitan Office Tower',
    type: 'office',
    location: {
      address: '1250 Broadway',
      city: 'New York',
      state: 'NY',
      country: 'USA',
      coordinates: { lat: 40.7505, lng: -73.9872 }
    },
    images: [
      'https://images.pexels.com/photos/2159065/pexels-photo-2159065.jpeg',
      'https://images.pexels.com/photos/373912/pexels-photo-373912.jpeg'
    ],
    specifications: {
      totalArea: 150000,
      occupancyRate: 95,
      yearBuilt: 2018,
      floors: 32
    },
    financial: {
      acquisitionPrice: 85000000,
      currentValue: 92000000,
      monthlyRent: 650000,
      annualYield: 7.8
    },
    status: 'active',
    description: 'Premium Grade A office space in the heart of Manhattan\'s Theater District.'
  },
  {
    id: '2',
    name: 'Sunset Shopping Center',
    type: 'retail',
    location: {
      address: '2500 Westheimer Rd',
      city: 'Houston',
      state: 'TX',
      country: 'USA',
      coordinates: { lat: 29.7372, lng: -95.4618 }
    },
    images: [
      'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg',
      'https://images.pexels.com/photos/2291017/pexels-photo-2291017.jpeg'
    ],
    specifications: {
      totalArea: 75000,
      occupancyRate: 88,
      yearBuilt: 2015,
      floors: 2
    },
    financial: {
      acquisitionPrice: 35000000,
      currentValue: 38500000,
      monthlyRent: 280000,
      annualYield: 8.5
    },
    status: 'active',
    description: 'Vibrant retail destination with anchor tenants and diverse shopping options.'
  },
  {
    id: '3',
    name: 'Harbor View Residences',
    type: 'residential',
    location: {
      address: '800 Harbor Blvd',
      city: 'San Francisco',
      state: 'CA',
      country: 'USA',
      coordinates: { lat: 37.7849, lng: -122.4094 }
    },
    images: [
      'https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg',
      'https://images.pexels.com/photos/1918291/pexels-photo-1918291.jpeg'
    ],
    specifications: {
      totalArea: 200000,
      occupancyRate: 92,
      yearBuilt: 2020,
      floors: 28
    },
    financial: {
      acquisitionPrice: 120000000,
      currentValue: 135000000,
      monthlyRent: 950000,
      annualYield: 7.2
    },
    status: 'active',
    description: 'Luxury waterfront residential complex with premium amenities and city views.'
  }
];

export const investmentOpportunities: InvestmentOpportunity[] = [
  {
    id: '1',
    title: 'Downtown Austin Mixed-Use Development',
    description: 'Ground-floor retail with luxury apartments in Austin\'s fastest-growing district.',
    targetAmount: 45000000,
    raisedAmount: 32000000,
    minimumInvestment: 25000,
    projectedYield: 9.2,
    timeline: '18 months',
    riskLevel: 'medium',
    status: 'open'
  },
  {
    id: '2',
    title: 'Industrial Logistics Hub - Phoenix',
    description: 'State-of-the-art warehouse and distribution center near major transportation routes.',
    targetAmount: 28000000,
    raisedAmount: 28000000,
    minimumInvestment: 50000,
    projectedYield: 7.8,
    timeline: '12 months',
    riskLevel: 'low',
    status: 'closed'
  }
];

export const newsArticles: NewsArticle[] = [
  {
    id: '1',
    title: 'SAIR Trust Acquires Premier Office Complex in Seattle',
    excerpt: 'Strategic acquisition strengthens our Pacific Northwest portfolio with Grade A office space.',
    content: 'Full article content would go here...',
    author: 'Investment Team',
    publishedAt: '2024-01-15',
    category: 'Acquisitions',
    image: 'https://images.pexels.com/photos/2159065/pexels-photo-2159065.jpeg'
  },
  {
    id: '2',
    title: 'Q4 2023 Performance Report: Exceeding Expectations',
    excerpt: 'Strong fundamentals drive portfolio performance above market benchmarks.',
    content: 'Full article content would go here...',
    author: 'Research Team',
    publishedAt: '2024-01-10',
    category: 'Performance',
    image: 'https://images.pexels.com/photos/590041/pexels-photo-590041.jpeg'
  }
];

export const teamMembers: TeamMember[] = [
  {
    id: '1',
    name: 'Sarah Chen',
    position: 'Chief Executive Officer',
    bio: 'Over 20 years of experience in real estate investment and portfolio management.',
    image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg'
  },
  {
    id: '2',
    name: 'Michael Rodriguez',
    position: 'Chief Investment Officer',
    bio: 'Former Goldman Sachs VP with expertise in commercial real estate valuations.',
    image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg'
  },
  {
    id: '3',
    name: 'Jennifer Park',
    position: 'Head of Asset Management',
    bio: 'Specializes in optimizing property performance and tenant relations.',
    image: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg'
  }
];

export const mockInvestorPortfolio: InvestorPortfolio = {
  totalInvestment: 250000,
  currentValue: 287500,
  totalReturn: 37500,
  monthlyDividend: 1850,
  properties: [
    {
      propertyId: '1',
      investmentAmount: 100000,
      currentValue: 115000,
      dividendYield: 7.8
    },
    {
      propertyId: '2',
      investmentAmount: 75000,
      currentValue: 86250,
      dividendYield: 8.5
    },
    {
      propertyId: '3',
      investmentAmount: 75000,
      currentValue: 86250,
      dividendYield: 7.2
    }
  ]
};